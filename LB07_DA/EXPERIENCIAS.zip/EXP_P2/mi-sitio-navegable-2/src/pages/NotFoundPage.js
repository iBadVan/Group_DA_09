
export const NotFoundPage = () => <h2>Error 404 - La página que buscas no
existe.</h2>;