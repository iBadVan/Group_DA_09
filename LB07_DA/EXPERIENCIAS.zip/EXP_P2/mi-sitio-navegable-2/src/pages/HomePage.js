
export const HomePage = () => {
 return (
 <div>
 <h2>Bienvenido a la Página de Inicio</h2>
 <p>Utiliza la navegación para explorar nuestros cursos.</p>
 </div>
 );
};
